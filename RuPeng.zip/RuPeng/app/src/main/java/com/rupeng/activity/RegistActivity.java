package com.rupeng.activity;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.rupeng.R;
import com.rupeng.bean.response.RegistResponse;
import com.rupeng.common.ApiAction;
import com.rupeng.widget.dialog.LoadDialog;
import com.sd.core.network.async.AsyncTaskManager;
import com.sd.core.network.http.HttpException;
import com.sd.core.utils.NToast;

/**
 * Created by AMing on 15/11/10.
 * Company RongCloud
 */
public class RegistActivity extends BaseActivity implements View.OnClickListener {

    private static final int REGIST_CODE = 2015;
    private EditText mEmail , mPassword ,mUserName;

    private Button mButton;

    protected Context mContext;

//    private ApiAction action;
    private String sEmail;
    private String sPassword;
    private String sUserName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rp_regist_activity);
        mContext = this;
        setTitle("注册");
//        mAsyncTaskManager = AsyncTaskManager.getInstance(mContext);
//        action = new ApiAction(mContext);
        initView();
    }

    private void initView() {
        mEmail = (EditText) findViewById(R.id.reg_email);
        mPassword = (EditText) findViewById(R.id.reg_password);
        mUserName = (EditText) findViewById(R.id.reg_username);
        mButton = (Button) findViewById(R.id.reg_button);
        mButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.reg_button:
                sEmail = mEmail.getText().toString().trim();
                sPassword = mPassword.getText().toString().trim();
                sUserName = mUserName.getText().toString().trim();
                if (TextUtils.isEmpty(sEmail)|TextUtils.isEmpty(sPassword)|TextUtils.isEmpty(sUserName)) {
                    Toast.makeText(this, "注册信息(邮箱,密码,昵称)不能为空", Toast.LENGTH_SHORT).show();
                }else{
                    LoadDialog.show(mContext);
                    request(REGIST_CODE);
                }
                break;
        }
    }

    @Override
    public Object doInBackground(int requestCode) throws HttpException {
        switch (requestCode) {
            case REGIST_CODE:
                return action.regist(sEmail,sPassword,sUserName,"13120241790");
        }
        return super.doInBackground(requestCode);
    }

    @Override
    public void onSuccess(int requestCode, Object result) {
        switch (requestCode){
            case REGIST_CODE:
                LoadDialog.dismiss(mContext);
                if (result != null) {
                    RegistResponse res = (RegistResponse)result;
                    NToast.shortToast(mContext, res.getCode()+res.getMessage());
                }
                break;
        }
    }

    @Override
    public void onFailure(int requestCode, int state, Object result) {
        switch (requestCode){
            case REGIST_CODE:
                NToast.shortToast(mContext,"注册失败");
                LoadDialog.dismiss(mContext);
                break;
        }
    }
}
