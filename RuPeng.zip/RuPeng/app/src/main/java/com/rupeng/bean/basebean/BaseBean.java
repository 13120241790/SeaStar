package com.rupeng.bean.basebean;


import java.io.Serializable;

/**
 * Created by AMing on 15/11/4.
 * Company RongCloud
 */
public abstract class BaseBean implements Serializable{
    private static final long serialVersionUID = 8021866358929646781L;
    //  File => Settings... => Inspections => Serialization issues => Serializable class without 'serialVersionUID'
}
