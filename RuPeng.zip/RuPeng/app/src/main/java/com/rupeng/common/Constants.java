package com.rupeng.common;

/**
 * Created by AMing on 15/11/10.
 * Company RongCloud
 */
public class Constants {

    //分页大小
    public static final int PAGESIZE = 21;
    //主域名
    public static final String DOMAIN = "http://webim.demo.rong.io/";
}
